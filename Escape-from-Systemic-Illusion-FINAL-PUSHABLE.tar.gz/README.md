Last login: Thu Jun 19 15:52:17 on ttys000
mirlindasinanaj@macbook-pro-de-mirlinda ~ % cd ~/Desktop/Escape-from-Systemic-Illusion-FINAL

mirlindasinanaj@macbook-pro-de-mirlinda Escape-from-Systemic-Illusion-FINAL % nano README.md


















  UW PICO 5.09                    File: README.md                     Modified  

# Escape from the Systemic Illusion

An interactive fiction game created with Inform 7 by Mirlinda Sinanaj.

## 🎮 How to Play

Play the game directly on [itch.io](https://msinanaj.itch.io/escape-form-the-sy$

Or download the `.z8` version from the [latest GitHub release](https://github.c$

## 🗂  Structure

- `.inform/` →  Inform 7 source code
- `.materials/` →  Release files (play.html, interpreter, assets)
- `.z8` →  Z-machine playable file
 




^G Get Help  ^O WriteOut  ^R Read File ^Y Prev Pg   ^K Cut Text  ^C Cur Pos   
^X Exit      ^J Justify   ^W Where is  ^V Next Pg   ^U UnCut Text^T To Spell  
# Escape-from-Systemic-Illusion-FINAL
